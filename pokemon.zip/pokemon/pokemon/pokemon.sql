-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 13/11/2024 às 16:07
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `pokemon`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `batalhas`
--

CREATE TABLE `batalhas` (
  `id_batalha` int(11) NOT NULL,
  `id_treinador1` int(11) DEFAULT NULL,
  `id_pokemon1` int(11) DEFAULT NULL,
  `id_treinador2` int(11) DEFAULT NULL,
  `id_pokemon2` int(11) DEFAULT NULL,
  `id_treinador_vencedor` int(11) DEFAULT NULL,
  `data` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `batalhas`
--

INSERT INTO `batalhas` (`id_batalha`, `id_treinador1`, `id_pokemon1`, `id_treinador2`, `id_pokemon2`, `id_treinador_vencedor`, `data`) VALUES
(1, 1, 1, 2, 3, 1, '2024-09-01'),
(2, 3, 4, 1, 2, 1, '2024-09-02'),
(3, 5, 6, 2, 3, 2, '2024-09-03'),
(4, 4, 5, 1, 1, 4, '2024-09-18'),
(5, 6, 7, 3, 4, 6, '2024-10-26'),
(6, 7, 8, 5, 6, 6, '2024-10-22'),
(7, 8, 9, 3, 4, 7, '2024-10-26'),
(8, 9, 10, 8, 9, 9, '2024-10-27');

-- --------------------------------------------------------

--
-- Estrutura para tabela `pokemon`
--

CREATE TABLE `pokemon` (
  `id_pokemon` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `nvl` int(11) NOT NULL,
  `descricao` text DEFAULT NULL,
  `comportamento` text DEFAULT NULL,
  `imagem_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `pokemon`
--

INSERT INTO `pokemon` (`id_pokemon`, `nome`, `tipo`, `nvl`, `descricao`, `comportamento`, `imagem_url`) VALUES
(1, 'pikachu', 'elétrico', 16, 'Conhecido por sua aparência adorável, com um corpo amarelo, orelhas pontudas e bochechas vermelhas que armazenam eletricidade.', 'Pikachu é geralmente amigável e sociável. Eles formam laços fortes com seus treinadores e costumam ser brincalhões. Quando se sentem ameaçados, podem liberar descargas elétricas.', 'https://th.bing.com/th/id/OIP.dvAnwdjqIXDO3ZdgFzMDMQHaHz?w=209&h=220&c=7&r=0&o=5&pid=1.7'),
(2, 'mewtwo', 'psiquico', 12, 'Um corpo laranja e uma chama na ponta de sua cauda. Essa chama é um sinal de sua saúde; se a chama apagar, significa que ele está fraco.', 'Charmander é muito leal e tem um espírito aventureiro. Ele é curioso e gosta de explorar novos lugares. Charmander também pode ser um pouco teimoso, mas é corajoso e protetor com aqueles que ama.', 'https://th.bing.com/th/id/OIP.WXVMxm34m05YQczYhrFgegHaJE?w=139&h=180&c=7&r=0&o=5&pid=1.7'),
(3, 'Bulbasaur', 'grama/veneno', 10, 'Caracterizado por um bulbo em suas costas que se transforma em uma planta ao longo do tempo. Seu corpo é verde e ele possui grandes patas e folhas.', 'Bulbassauro é calmo e equilibrado. Ele se alimenta da luz solar, utilizando seu bulbo para crescer. Ele é leal a seu treinador e frequentemente usa suas habilidades de Grama para ajudar em batalhas.', 'https://th.bing.com/th/id/OIP.NGlTrdvwjAZfFOG0v6IpiwHaG1?w=216&h=199&c=7&r=0&o=5&pid=1.7'),
(4, 'Squirtle', 'água', 9, ' Parecido com uma pequena tartaruga azul. Ele tem um casco duro que o protege e é conhecido por sua habilidade de lançar jatos de água.', 'Squirtle é brincalhão e energético. Ele é curioso e gosta de nadar, sendo muito ágil na água. Squirtle é também muito sociável e forma rapidamente laços com seus treinadores.', 'https://th.bing.com/th/id/OIP.feSPmUDsUQ9fVAWa6WWVuAHaG1?w=212&h=196&c=7&r=0&o=5&pid=1.7'),
(5, 'Umbreon', 'noturno', 18, 'Ele é uma das evoluções de Eevee e é conhecido por sua habilidade de se mover silenciosamente na escuridão.', 'Umbreon é reservado e cauteloso. Ele é extremamente leal ao seu treinador e possui uma natureza protetora. Umbreon se torna mais ativo à noite e é um lutador astuto.', 'https://th.bing.com/th/id/OIP.ACl1pufiaw6HUGU0SEvYNgHaHa?w=199&h=199&c=7&r=0&o=5&pid=1.7'),
(6, 'Jigglypuff', 'fada', 7, 'Ele é conhecido por sua habilidade de cantar uma canção de ninar que faz as pessoas e Pokémon adormecerem.', 'Jigglypuff é brincalhão e gosta de se apresentar, mas fica frustrado quando seu público adormece. Ele é amigável e usa sua habilidade de canto para se divertir e fazer amigos.', 'https://th.bing.com/th?id=OSK.ac00d5d2db30d8f14666623f4de5c85f&w=102&h=102&c=7&o=6&pid=SANGAM'),
(7, 'Pidgey', 'voador/normal', 10, 'Pequeno pássaro Pokémon com penas marrons e uma cauda curta. É conhecido por sua habilidade de voar longas distâncias.', 'Pidgey é pacífico e prefere evitar lutas, mas pode se tornar agressivo se for ameaçado. Ele é extremamente fiel ao seu treinador e sempre retorna ao seu ninho.', 'https://th.bing.com/th?id=OSK.yr4yEtBs6cWRhLhMvyvLFzlvRB18hXJDJTUCJH5jd1g&w=102&h=102&o=6&pid=SANGAM'),
(8, 'Flareon', 'fogo', 16, 'Flareon é conhecido por seu pelo vermelho-alaranjado e fofo, e por sua habilidade de aumentar a temperatura do seu corpo para lançar chamas poderosas.', 'Flareon é leal e afetuoso com seu treinador, mas pode ser um pouco reservado com estranhos. Ele é corajoso em batalhas e se destaca em resistir a ataques com seu pelo espesso que o protege do calor intenso.', 'https://th.bing.com/th/id/OIP.amDSJkHnRSvnvMRGGjpuXwHaHa?w=218&h=218&c=7&r=0&o=5&pid=1.7'),
(9, 'Eevee', 'normal', 10, 'Eevee é um Pokémon de aparência adorável, conhecido por sua versatilidade em evoluir em diferentes formas, dependendo das condições em que se encontra.', 'Eevee é geralmente brincalhão e curioso. Eles são afetuosos com seus treinadores e gostam de explorar seu ambiente. Por serem tão adaptáveis, os Eevees podem se dar bem em uma variedade de situações.', 'https://th.bing.com/th/id/OIP.DQTDE8xw3yRH6eMBbli27QHaHa?w=182&h=182&c=7&r=0&o=5&pid=1.7'),
(10, 'Arceus', 'normal', 20, 'Arceus é conhecido como o \"Pokémon Deus\", e é reverenciado em muitas culturas dentro do universo Pokémon. Sua aparência é semelhante a um cavalo branco com uma forma majestosa.', 'Arceus é sábio e protetor, geralmente demonstrando uma natureza calma. É dito que ele cria e controla o universo, o que o torna um Pokémon muito poderoso e respeitado.', 'https://th.bing.com/th/id/OIP.FAn9vBsl6ylRfbOh5_B_rQHaHa?w=158&h=180&c=7&r=0&o=5&pid=1.7');

-- --------------------------------------------------------

--
-- Estrutura para tabela `treinadores`
--

CREATE TABLE `treinadores` (
  `id_treinador` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `idade` int(11) NOT NULL,
  `cidade` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `treinadores`
--

INSERT INTO `treinadores` (`id_treinador`, `nome`, `idade`, `cidade`) VALUES
(1, 'Ash', 10, 'Pallet'),
(2, 'Misty', 12, 'Cerulean'),
(3, 'Brock', 15, 'Pewter'),
(4, 'Raissa', 19, 'Rio de Janeiro'),
(5, 'Gary', 11, 'Pallet'),
(6, 'Letícia', 18, ' Rio de janeiro'),
(7, 'Ranna', 17, 'Rio de Janeiro'),
(8, 'Gustavo', 18, 'Rio de Janeiro'),
(9, 'Rodrigo', 17, 'Rio de Janeiro');

-- --------------------------------------------------------

--
-- Estrutura para tabela `treinador_pokemon`
--

CREATE TABLE `treinador_pokemon` (
  `id_treinador` int(11) NOT NULL,
  `id_pokemon` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `treinador_pokemon`
--

INSERT INTO `treinador_pokemon` (`id_treinador`, `id_pokemon`) VALUES
(1, 1),
(1, 2),
(2, 3),
(3, 4),
(4, 5),
(5, 6),
(6, 7),
(7, 8),
(8, 9),
(9, 10);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `batalhas`
--
ALTER TABLE `batalhas`
  ADD PRIMARY KEY (`id_batalha`),
  ADD KEY `id_treinador1` (`id_treinador1`),
  ADD KEY `id_pokemon1` (`id_pokemon1`),
  ADD KEY `id_treinador2` (`id_treinador2`),
  ADD KEY `id_pokemon2` (`id_pokemon2`),
  ADD KEY `id_treinador_vencedor` (`id_treinador_vencedor`);

--
-- Índices de tabela `pokemon`
--
ALTER TABLE `pokemon`
  ADD PRIMARY KEY (`id_pokemon`);

--
-- Índices de tabela `treinadores`
--
ALTER TABLE `treinadores`
  ADD PRIMARY KEY (`id_treinador`);

--
-- Índices de tabela `treinador_pokemon`
--
ALTER TABLE `treinador_pokemon`
  ADD PRIMARY KEY (`id_treinador`,`id_pokemon`),
  ADD KEY `id_pokemon` (`id_pokemon`);

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `batalhas`
--
ALTER TABLE `batalhas`
  ADD CONSTRAINT `batalhas_ibfk_1` FOREIGN KEY (`id_treinador1`) REFERENCES `treinadores` (`id_treinador`),
  ADD CONSTRAINT `batalhas_ibfk_2` FOREIGN KEY (`id_pokemon1`) REFERENCES `pokemon` (`id_pokemon`),
  ADD CONSTRAINT `batalhas_ibfk_3` FOREIGN KEY (`id_treinador2`) REFERENCES `treinadores` (`id_treinador`),
  ADD CONSTRAINT `batalhas_ibfk_4` FOREIGN KEY (`id_pokemon2`) REFERENCES `pokemon` (`id_pokemon`),
  ADD CONSTRAINT `batalhas_ibfk_5` FOREIGN KEY (`id_treinador_vencedor`) REFERENCES `treinadores` (`id_treinador`);

--
-- Restrições para tabelas `treinador_pokemon`
--
ALTER TABLE `treinador_pokemon`
  ADD CONSTRAINT `treinador_pokemon_ibfk_1` FOREIGN KEY (`id_treinador`) REFERENCES `treinadores` (`id_treinador`),
  ADD CONSTRAINT `treinador_pokemon_ibfk_2` FOREIGN KEY (`id_pokemon`) REFERENCES `pokemon` (`id_pokemon`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
