const express = require('express');
const mysql = require('mysql2');
const ejs = require('ejs');
const path = require('path');

const app = express();
const port = 3000;

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));  // Para tratar formulários POST
app.use('/assets', express.static(path.join(__dirname, 'assets')));

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'pokemon'
});

db.connect((error) => {
    if (error) {
        console.log('Erro ao conectar com o MySQL', error);
    } else {
        console.log('Conectado ao MySQL!');
    }
});

// visualizar um treinador específico
app.get('/treino/:id', (req, res) => {
    const id = req.params.id;

    db.query('SELECT * FROM treinadores WHERE id_treinador = ?', [id], (error, results) => {
        if (error) {
            console.log('Erro ao buscar treinador', error);
            res.status(500).send('Erro interno ao buscar treinador');
        } else if (results.length === 0) {
            res.status(404).send('Treinador não encontrado');
        } else {
            res.render('treino', { treinador: results[0] });
        }
    });
});

// editar um treinador
app.post('/editarTreinador/:id', (req, res) => {
    const id = req.params.id;
    const { nome, cidade, idade } = req.body;

    db.query(
        'UPDATE treinadores SET nome = ?, cidade = ?, idade = ? WHERE id_treinador = ?',
        [nome, cidade, idade, id],
        (error, results) => {
            if (error) {
                console.log('Erro ao atualizar treinador', error);
                res.status(500).send('Erro interno ao atualizar treinador');
            } else {
                res.redirect('/treinadores');
            }
        }
    );
});

// Home
app.get('/', (req, res) => {
    db.query('SELECT * FROM pokemon', (error, results) => {
        if (error) {
            console.log('Erro ao buscar os pokemons', error);
            res.status(500).send('Erro interno do servidor');
        } else {
            res.render('home', { pokemons: results });
        }
    });
});

// Treinadores
app.get('/treinadores', (req, res) => {
    const nome = req.query.nome || '';
    const cidade = req.query.cidade || '';
    const idade = req.query.idade || '';

    let query = 'SELECT * FROM treinadores WHERE 1=1';
    const params = [];

    if (nome) {
        query += ' AND nome LIKE ?';
        params.push(`%${nome}%`);
    }
    if (cidade) {
        query += ' AND cidade LIKE ?';
        params.push(`%${cidade}%`);
    }
    if (idade) {
        query += ' AND idade = ?';
        params.push(idade);
    }

    db.query(query, params, (error, results) => {
        if (error) {
            console.log('Houve um erro ao buscar os treinadores', error);
        } else {
            res.render('treinadores', { treinadores: results });
        }
    });
});

// Batalhas
app.get('/batalhas', (req, res) => {
    const treinador = req.query.treinador || '';
    const pokemon = req.query.pokemon || '';
    const data = req.query.data || '';

    let query = `
    SELECT 
        b.id_batalha, 
        t1.id_treinador AS id_treinador1,
        t1.nome AS treinador1, 
        p1.nome AS pokemon1, 
        t2.id_treinador AS id_treinador2,
        t2.nome AS treinador2, 
        b.id_treinador_vencedor, 
        p2.nome AS pokemon2, 
        b.data 
    FROM batalhas b
    JOIN treinadores t1 ON b.id_treinador1 = t1.id_treinador
    JOIN treinadores t2 ON b.id_treinador2 = t2.id_treinador
    JOIN pokemon p1 ON b.id_pokemon1 = p1.id_pokemon
    JOIN pokemon p2 ON b.id_pokemon2 = p2.id_pokemon
    WHERE 1=1
    `;

    const params = [];

    if (treinador) {
        query += ' AND (t1.nome LIKE ? OR t2.nome LIKE ?)';
        params.push(`%${treinador}%`, `%${treinador}%`);
    }
    if (pokemon) {
        query += ' AND (p1.nome LIKE ? OR p2.nome LIKE ?)';
        params.push(`%${pokemon}%`, `%${pokemon}%`);
    }
    if (data) {
        query += ' AND b.data = ?';
        params.push(data);
    }

    db.query(query, params, (error, results) => {
        if (error) {
            console.log('Houve um erro ao buscar as batalhas', error);
            res.status(500).send('Erro interno do servidor');
        } else {
            results.forEach(batalha => {
                const idVencedor = Number(batalha.id_treinador_vencedor);
                const idTreinador1 = Number(batalha.id_treinador1);
                const idTreinador2 = Number(batalha.id_treinador2);

                if (idVencedor === idTreinador1) {
                    batalha.vencedor = batalha.treinador1;
                } else if (idVencedor === idTreinador2) {
                    batalha.vencedor = batalha.treinador2;
                } else {
                    batalha.vencedor = 'Nenhum vencedor determinado!';
                }
            });

            res.render('batalhas', { batalhas: results });
        }
    });
});

// editar batalha
app.get('/editarBatalha/:id_batalha', (req, res) => {
    const id_batalha = req.params.id_batalha;
  
    // Buscar batalha pelo ID
    db.query('SELECT * FROM batalhas WHERE id_batalha = ?', [id_batalha], (error, results) => {
      if (error) {
        console.log('Erro ao buscar a batalha', error);
        res.status(500).send('Erro interno do servidor');
      } else if (results.length === 0) {
        res.status(404).send('Batalha não encontrada');
      } else {
        const batalha = results[0];
  
       
        db.query('SELECT * FROM treinadores', (error, treinadores) => {
          if (error) {
            console.log('Erro ao buscar treinadores', error);
            res.status(500).send('Erro interno ao buscar treinadores');
          } else {
          
            res.render('editarBatalha', { batalha: batalha, treinadores: treinadores });
          }
        });
      }
    });
  });
  
  
// Atualizar a Batalha (POST)
app.post('/atualizarBatalha/:id', (req, res) => {
    const idBatalha = req.params.id;
    const { treinador1, treinador2, pokemon1, pokemon2, vencedor, data } = req.body;

    const query = `
        UPDATE batalhas
        SET id_treinador1 = ?, id_treinador2 = ?, id_pokemon1 = ?, id_pokemon2 = ?, id_treinador_vencedor = ?, data = ?
        WHERE id_batalha = ?
    `;
    const values = [treinador1, treinador2, pokemon1, pokemon2, vencedor, data, idBatalha];

    db.query(query, values, (error, results) => {
        if (error) {
            console.error('Erro ao atualizar a batalha:', error);
            res.status(500).send('Erro ao atualizar a batalha.');
        } else {
            res.redirect('/batalhas'); // Redireciona de volta para a página de batalhas
        }
    });
});

  
//visualizar informações de um Pokémon
app.get('/infoPokemon', (req, res) => {
    const id_pokemon = req.query.id_pokemon;

    if (!id_pokemon) {
        return res.status(400).send('ID do Pokémon não fornecido.');
    }

    db.query('SELECT * FROM pokemon WHERE id_pokemon = ?', [id_pokemon], (error, results) => {
        if (error) {
            console.log('Erro ao buscar Pokémon', error);
            return res.status(500).send('Erro ao buscar Pokémon.');
        }

        if (results.length === 0) {
            return res.status(404).send('Pokémon não encontrado.');
        }

       
        res.render('infoPokemon', { pokemon: results[0] });
    });
});

app.post('/editarPokemon/:id_pokemon', (req, res) => {
    const id_pokemon = req.params.id_pokemon;
    const { inputNome, inputTipo, inputnvl, imagem_url, inputDescricao, inputComportamento } = req.body;

    //  dados necessários estão sendo passados
    console.log(req.body); 

    const query = `
        UPDATE pokemon SET 
        nome = ?, 
        tipo = ?, 
        nvl = ?, 
        imagem_url = ?, 
        descricao = ?, 
        comportamento = ? 
        WHERE id_pokemon = ?
    `;
    
    const params = [inputNome, inputTipo, inputnvl, imagem_url, inputDescricao, inputComportamento, id_pokemon];

    db.query(query, params, (error, results) => {
        if (error) {
            console.log('Erro ao atualizar Pokémon', error); 
            return res.status(500).send('Erro ao atualizar Pokémon.');
        }

       
        res.redirect(`/infoPokemon?id_pokemon=${id_pokemon}`);
    });
});

//  Pokémons de um treinador específico
app.get('/pokemons/:id_treinador', (req, res) => {
    const id_treinador = req.params.id_treinador;
    
   
    db.query(
      'SELECT p.id_pokemon, p.nome FROM pokemon p JOIN treinador_pokemon tp ON p.id_pokemon = tp.id_pokemon WHERE tp.id_treinador = ?',
      [id_treinador],
      (error, results) => {
        if (error) {
          console.log('Erro ao buscar Pokémons', error);
          res.status(500).send('Erro ao buscar Pokémons');
        } else {
          res.json(results);
        }
      }
    );
  });

  // Rota: Atualizar treinador
// Rota para salvar o treinador
// Rota para renderizar o formulário de adicionar treinador
app.get('/adicionarTreinador', (req, res) => {
    res.render('adicionarTreinador'); // Isso renderiza a página HTML do formulário de adicionar treinador
});

app.post('/salvarTreinador', (req, res) => {
    const { nome, cidade, idade } = req.body;

    // Verifique se todos os campos foram preenchidos
    if (!nome || !cidade || !idade) {
        return res.status(400).send('Todos os campos são obrigatórios.');
    }

    // Query para inserir o novo treinador no banco de dados
    const query = `
        INSERT INTO treinadores (nome, cidade, idade)
        VALUES (?, ?, ?)
    `;
    const values = [nome, cidade, idade];

    db.query(query, values, (error, results) => {
        if (error) {
            console.error('Erro ao salvar treinador:', error);
            return res.status(500).send('Erro ao salvar treinador.');
        }

        // Após salvar o treinador, redireciona para a página de treinadores
        res.redirect('/treinadores');
    });
});


// Rota: Atualizar batalha
app.post('/adicionarBatalha', (req, res) => {
    const { treinador1, pokemon1, treinador2, pokemon2, data } = req.body;
    
    // Verifique os dados recebidos
    console.log('Dados recebidos para adicionar batalha:', req.body);

    // Verifique se todos os campos necessários estão sendo enviados
    if (!treinador1 || !pokemon1 || !treinador2 || !pokemon2 || !data) {
        return res.status(400).send('Todos os campos são obrigatórios');
    }

    // Query para inserir a batalha no banco de dados
    const query = `
        INSERT INTO batalhas (id_treinador1, id_pokemon1, id_treinador2, id_pokemon2, data)
        VALUES (?, ?, ?, ?, ?)
    `;
    
    db.query(query, [treinador1, pokemon1, treinador2, pokemon2, data], (error, results) => {
        if (error) {
            console.error('Erro ao adicionar batalha:', error);
            return res.status(500).send('Erro ao adicionar batalha');
        } else {
            console.log('Batalha adicionada com sucesso!');
            res.redirect('/batalhas'); // Redireciona para a lista de batalhas
        }
    });
});


// Rota para exibir o formulário de adicionar batalha
app.get('/adicionarBatalha', (req, res) => {
    // Aqui você pode buscar os treinadores e pokémons do banco, se necessário
    db.query('SELECT * FROM treinadores', (error, treinadores) => {
        if (error) {
            console.log('Erro ao buscar treinadores', error);
            res.status(500).send('Erro ao buscar treinadores');
        } else {
            // Renderiza a página com o formulário de adicionar batalha
            res.render('adicionarBatalha', { treinadores: treinadores });
        }
    });
});



// Rota para remover batalha
app.post('/removerBatalha/:id_batalha', (req, res) => {
    const idBatalha = req.params.id_batalha;

    // Verificando o ID que está sendo passado
    console.log('Removendo batalha com ID:', idBatalha);

    // Query SQL para excluir a batalha com o ID especificado
    db.query('DELETE FROM batalhas WHERE id_batalha = ?', [idBatalha], (error, results) => {
        if (error) {
            console.error('Erro ao remover a batalha:', error);
            return res.status(500).send('Erro ao remover a batalha.');
        }

        // Após a remoção, redirecionar para a lista de batalhas
        res.redirect('/batalhas'); // Redireciona para a lista de batalhas
    });
});

// Rota para remover treinador
app.post('/removerTreinador/:id_treinador', (req, res) => {
    const idTreinador = req.params.id_treinador;
    console.log('ID recebido para remoção:', idTreinador); // Log para debug

    db.query('DELETE FROM treinadores WHERE id_treinador = ?', [idTreinador], (error, results) => {
        if (error) {
            console.error('Erro ao remover o treinador:', error);
            return res.status(500).send('Erro ao remover o treinador.');
        }

        console.log('Treinador removido com sucesso!'); // Log de sucesso
        res.redirect('/treinadores');
    });
});

// Rota para excluir um Pokémon

app.post('/removerPokemon/:id_pokemon', (req, res) => {
    const id_pokemon = req.params.id_pokemon;

    // Query para excluir o Pokémon
    db.query('DELETE FROM pokemon WHERE id_pokemon = ?', [id_pokemon], (error, results) => {
        if (error) {
            console.log('Erro ao excluir Pokémon', error);
            res.status(500).send('Erro ao excluir Pokémon.');
        } else {
            res.redirect('/'); // Redireciona para a página inicial ou outra página desejada
        }
    });
});

// Rota para pesquisa (GET)
app.get('/pesquisarHome', (req, res) => {
    const pesquisa = req.query.pesquisa || ''; // Obtém o valor de pesquisa

    // Montar a consulta para buscar pokémons com base no nome
    let query = 'SELECT * FROM pokemon WHERE nome LIKE ?';
    const params = [`%${pesquisa}%`];

    // Executar a consulta no banco de dados
    db.query(query, params, (error, results) => {
        if (error) {
            console.log('Erro ao buscar Pokémon', error);
            res.status(500).send('Erro interno ao buscar Pokémon.');
        } else {
            // Retornar os resultados da pesquisa
            res.render('home', { pokemons: results });
        }
    });
});

app.get('/adicionarPokemon', (req, res) => {
    res.render('adicionarPokemon'); // Renderiza a página de formulário
});
// Rota para processar a adição de Pokémon
app.post('/adicionarPokemon', (req, res) => {
    const { nome, tipo, nvl, imagem_url, descricao, comportamento } = req.body;

    // Validação básica
    if (!nome || !tipo || !nvl || !imagem_url || !descricao || !comportamento) {
        return res.status(400).send('Todos os campos são obrigatórios.');
    }

    // Inserir o Pokémon no banco de dados
    db.query(
        'INSERT INTO pokemon (nome, tipo, nvl, imagem_url, descricao, comportamento) VALUES (?, ?, ?, ?, ?, ?)',
        [nome, tipo, nvl, imagem_url, descricao, comportamento],
        (error, results) => {
            if (error) {
                console.log('Erro ao adicionar Pokémon:', error);
                return res.status(500).send('Erro ao adicionar Pokémon.');
            }
            res.redirect('/'); // Redireciona para a página inicial (ou outra página desejada)
        }
    );
});

app.listen(port, () => {
    console.log(`Servidor iniciado na porta ${port}`);
});
